package com.foodordersystem;

import java.util.Scanner;

public class Foodorder {

	int FrenchFries = 100;
	int Burger = 120;
	int Pastry = 50;
	int Sandwich = 80;
	int Pizza = 200;
	int ColdCofee = 35;
	int Coldrinks = 25;
	int HotTea = 15;
	int ch;
	int Quantity;
	static double total;
	String again;
	double finalbill;
	static int sgst;
	int cgst;

	Scanner sc = new Scanner(System.in);

	public void display() {
		System.out.println("******************** Welcome to Our Cafe ********************");
		System.out.println("=============================================================");
		System.out.println("          1.French Fries        100/-");
		System.out.println("          2.Burger        	120/-");
		System.out.println("          3.Pastry              50/-");
		System.out.println("          4.Sandwich            80/-");
		System.out.println("          5.Pizza               200/-");
		System.out.println("          6.ColdCofee           35/-");
		System.out.println("          7.Coldrinks           25/-");
		System.out.println("          8.HotTea              15/-");
		System.out.println("          9.Exit.....                ");
		System.out.println("=============================================================");
		System.out.println("What do you want to Order Today ???");

	}

	public void generateBill() {
		System.out.println();
		System.out.println("************ Thank You for Ordering ************");
		System.out.println("************ Your Sub Total  : " + total + " ************");
		double sgst = total * 2.50 / 100;
		System.out.println("************   sgst:> 2.50%  : " + sgst + " ************");
		double cgst = total * 2.50 / 100;
		System.out.println("************   cgst:> 2.50%  : " + cgst + " ************");
		double finalbill = total + sgst + cgst;
		System.out.println("************ The Food Total  : " + finalbill + " ************");
		System.out.println("===============================================================");

	}

	public void order() {
		while (true) {
			System.out.println("***** Enter Your Choice *****");
			ch = sc.nextInt();
			switch (ch) {
			case 1:// French Fries
				System.out.println("You have Selected French Fries");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * FrenchFries;

				break;

			case 2:// Burger
				System.out.println("You have Selected Burger");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * Burger;

				break;

			case 3:// Pastry
				System.out.println("You have Selected Pastry");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * Pastry;

				break;

			case 4:// Sandwich
				System.out.println("You have Selected Sandwich");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * Sandwich;

				break;

			case 5:// Pizza
				System.out.println("You have Selected Pizza");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * Pizza;

				break;

			case 6:// Cold Coffee
				System.out.println("You have Selected Cold Coffee");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * ColdCofee;

				break;

			case 7:// Coldrinks
				System.out.println("You have Selected Coldrinks");
				System.out.println();
				System.out.println("Enter the Desired Quantity :");
				Quantity = sc.nextInt();
				total = total + Quantity * Coldrinks;

				break;

			case 8:// HotTea
				System.out.println("You have Selected HotTea");
				System.out.println();
				System.out.println("Enter the Desired Quantity : ");
				Quantity = sc.nextInt();
				total = total + Quantity * HotTea;

				break;

			case 9:// Exit
				System.exit(1);
				break;

			default:
				break;

			}
			System.out.println();
			System.out.print("Do you wish to Order Anything else (Y/N) : ");
			again = sc.next();
			if (again.equalsIgnoreCase("Y")) {
				order();
			} else if (again.equalsIgnoreCase("N")) {
				generateBill();
				System.exit(1);
			} else {
				System.out.println("Invalid Choice");
			}

		}
	}

}
