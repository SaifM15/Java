package com.foodordersystem;

public class TestFoodOrder {

	public static void main(String[] args) {
		
		Foodorder fo= new Foodorder();
		fo.display();
		
		fo.order();
	}

}
