package stringassignments;

public class SearchString{
	   public static void main(String[] args) {
	      String strOrig = "Hello readers";
	      int intIndex = strOrig.indexOf("readers");
	      
	      if(intIndex == - 1) {
	         System.out.println("readers not found");
	      } else {
	         System.out.println("Found readers at index " + intIndex);
	      }
	   }
	}