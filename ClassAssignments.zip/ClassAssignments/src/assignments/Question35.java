//Write a program to accept two number and find the smallest number

package assignments;

import java.util.Scanner;

public class Question35 {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner (System.in);
		
		System.out.println("Write a first Number");
		int firstNumber=sc.nextInt();
		System.out.println("Write a Second Number");
		int secondNumber=sc.nextInt();
					
			if(firstNumber>=secondNumber) {
				System.out.println(+secondNumber + " Second Number is smallest");
			}else {
				System.out.println(+firstNumber + "First number is smallest ");
			}
			
		}

	}
