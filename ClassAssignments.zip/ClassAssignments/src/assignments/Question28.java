//Generate the Series 10 20 30 40 50 60 70 80 90 100

package assignments;

public class Question28 {

	public static void main(String[] args) {
		for (int i = 10; i <= 100; i++) {
			if (i % 10 == 0) {
				System.out.print(" " + i);
			}
		}
	}
}
