package assignments;

public class GreaterNumber {

	public static void main(String[] args) {
		
		int a=100;
		int b=200;
		
		if(a>=b) {
			System.out.println("A is greater than B");
		}else {
			System.out.println("B is Greater than A");
		}
	}

}
