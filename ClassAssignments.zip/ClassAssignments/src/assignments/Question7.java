// Write a program to print -45 to +45 numbers
package assignments;

public class Question7 {

	public static void main(String[] args) {
		
		for(int i=-45;i<=45;i++) {
			System.out.println(i);
		}
	}

}
