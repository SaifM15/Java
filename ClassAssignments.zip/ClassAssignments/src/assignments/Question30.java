//Generate the Series  6 12 18 24 30 36 42 48 54 60

package assignments;

public class Question30 {

	public static void main(String[] args) {
		for (int i = 6; i <= 60; i++) {
			if (i % 6 == 0) {
				System.out.print(" " + i);
			}
		}

	}

}
