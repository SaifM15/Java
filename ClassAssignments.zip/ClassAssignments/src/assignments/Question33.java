//Write a Program to accept a number and find it is even and Odd

package assignments;

import java.util.Scanner;

public class Question33 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		
		int no=sc.nextInt();
		
		if(no%2 == 0) {
			System.out.println("This " +no+ " is Even");
		}
		else {
			System.out.println("This " +no+ " is Odd");

		}
	}

}
