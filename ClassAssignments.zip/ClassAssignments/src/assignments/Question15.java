package assignments;

public class Question15 {

	public static void main(String[] args) {
		
		int oddCount = 0;
		for (int i = 1; i <= 25; i++) {
			if (i % 2 != 0) {
				oddCount++;
			}
		}
		System.out.println("The Odd number Count is " + oddCount);
	}

}
