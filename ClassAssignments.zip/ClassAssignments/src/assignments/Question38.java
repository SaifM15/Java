// Write a program to accept two number and find the sum of two even number

package assignments;

import java.util.Scanner;

public class Question38 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Write a first Number");
		int firstNumber = sc.nextInt();

		System.out.println("Write a Second Number");
		int secondNumber = sc.nextInt();

		if (firstNumber % 2 != 0 && secondNumber % 2 != 0) {

			int sum = firstNumber + secondNumber;
			System.out.println("Sum of the two odd numbers is: " + sum);
		} else {
			System.out.println("Please enter two odd numbers to find their sum.");

		}

	}
}
