//  Write a program to print 1 to 100 numbers
package assignments;

public class Question11 {

	public static void main(String[] args) {

		for(int i=1; i<=100;i++) {
			System.out.println(i);
		}
		

	}

}
