//Generate the series 1 4 9 16 25 36 49 64 81 100

package assignments;

public class Question24 {
	public static void main(String []args) {
		
		for(int i=1;i<=10;i++) {
			 
			int series=i*i;
			System.out.print(" " +series);
		}
	}

}
