//Write a program to print sum of odd and even numbers

package assignments;

public class Question9 {
	public static void main(String[] args) {
		int sumOdd = 0;
        int sumEven = 0;

       
        for (int i = 1; i <= 50; i++) {
            
            if (i % 2 != 0) {
                
                sumOdd += i;
                
            } else {
                
                sumEven += i;
            }
        }


        System.out.println("Sum of odd numbers from 1 to 50: " + sumOdd);
        System.out.println("Sum of even numbers from 1 to 50: " + sumEven);
    
		
	}

}
