// Write a program to print even and odd numbers
package assignments;

public class Question10 {

	public static void main(String[] args) {
		
		

	}

}
