//Generate the series  4 8 12 16 20 24 28 32 36 40

package assignments;

public class Question27 {

	public static void main(String[] args) {
		
		for (int i = 4; i <= 40; i++) {
			if (i % 4 == 0) {
				System.out.print(" " + i);
			}
		}
	}
}
