package assignments;

public class Calculator {

	public static void main(String[] args) {
		
		int a=10;
		int b= 20;
		String ch ="+";
		
		
//		if(ch) {
			
		}
	}

//}
