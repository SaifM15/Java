package assignments;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		
		int no=sc.nextInt();
		
		if(no%2 == 0) {
			System.out.println("This " +no+ " is Even");
		}
		else {
			System.out.println("This " +no+ " is Odd");

		}
				}

}
