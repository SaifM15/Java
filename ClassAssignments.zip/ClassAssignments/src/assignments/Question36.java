//Write a program to accept two number and find the largest number

package assignments;

import java.util.Scanner;

public class Question36 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Write a first Number");
		int firstNumber = sc.nextInt();
		System.out.println("Write a Second Number");
		int secondNumber = sc.nextInt();

		if (firstNumber >= secondNumber) {
			System.out.println(+firstNumber + " First Number is largest");
		} else {
			System.out.println(+secondNumber + " Second number is largest ");
		}

	}

}
