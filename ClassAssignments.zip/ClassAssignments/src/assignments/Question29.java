//Generate the series 1 2 3 4 5 4 3 2 1

package assignments;

public class Question29 {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++) {
			System.out.print(i+" ");
		}
		
		for(int i=4;i>=1;i--) {
			System.out.print(i+" ");
		}
		
		

	}

}
