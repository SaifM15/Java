//Generate the Series 5 10 15 20 25 30 35 40 45 50

package assignments;

public class Question19 {

	public static void main(String[] args) {
		
		for(int i=5;i<=50;i++) {
			if(i%5==0) {
				System.out.print(" "+i);
			}
		}
	}

}
