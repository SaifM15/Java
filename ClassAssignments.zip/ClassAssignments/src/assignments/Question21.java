//Generate the series 1 3 6 10 15 21 28 36 45
package assignments;

public class Question21 {

	public static void main(String[] args) {
		int term = 1;
        int increment = 2;

        for (int i = 0; i < 9; i++) {
            System.out.print(term + " ");
            term += increment;
            increment++;
        }
	}

}
