//Write a program to accept a number and find it is Even No

package assignments;

import java.util.Scanner;

public class Question31 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Number :- ");
		
		int no=sc.nextInt();		
		if(no%2==0) {
			System.out.println(no + " This is Even number");
		}else {
			System.out.println(no + " This is not Even Number");
		}
		
	}

}
