//Write a program to print 30 to 50 numbers

package assignments;

public class Question13 {

	public static void main(String[] args) {
		
		for (int i = 30; i <= 50; i++) {
			System.out.println(i);
		}

	}

}
