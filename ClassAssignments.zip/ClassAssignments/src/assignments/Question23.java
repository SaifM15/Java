//Generate  the Series 0 1 1 2 3 5 8 13 21

package assignments;

public class Question23 {

	public static void main(String[] args) {

		int a = 0;
		int b = 1;
		System.out.print(a+" "+b);
		
		int c;

		for (int i = 0; i <= 7; i++) {
			
			c=a+b;
			System.out.print(" "+c);
			a=b;
			b=c;
			
			
		}

	}

}
