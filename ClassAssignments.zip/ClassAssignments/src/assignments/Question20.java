//Generate the series 1 10 100 1000

package assignments;

public class Question20 {

	public static void main(String[] args) {
		
		int term = 1;

        for (int i = 0; i < 4; i++) {
            System.out.print(term + " ");
            term *= 10;
        }
		
	}

}
