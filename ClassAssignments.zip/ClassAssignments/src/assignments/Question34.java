//Write a program to accept a number and find it Zero, Positive or Negative

package assignments;

import java.util.Scanner;

public class Question34 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a number: ");
		int number = sc.nextInt();

		if (number == 0) {
			System.out.println("The entered number is Zero.");
		} else if (number > 0) {
			System.out.println("The entered number is Positive.");
		} else {
			System.out.println("The entered number is Negative.");
		}

	}

}
