// Write a Program to Print 1 to 25 numbers

package assignments;

public class Question1 {

	public static void main(String[] args) {
		
		for(int i=1;i<=25;i++) {
			System.out.println();
		}

	}

}
