//Generate the series 8 16 24 32 40 48 56 64 72 80

package assignments;

public class Question22 {

	public static void main(String[] args) {
		
		for(int i=8; i<=80;i++) {
			if(i%8==0) {
				System.out.print(" "+i);
			}
		}
		
	}

}
