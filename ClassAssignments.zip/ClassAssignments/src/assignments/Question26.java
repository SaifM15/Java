//Generate the series 7 14 21 28 35 42 49 56 63 70

package assignments;

public class Question26 {

	public static void main(String[] args) {
		for (int i = 7; i <= 70; i++) {
			if (i % 7 == 0) {
				System.out.print(" " + i);
			}
		}
	}
}
