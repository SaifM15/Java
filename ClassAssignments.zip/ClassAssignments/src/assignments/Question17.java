//Generate the series 9 18 27 36 45 54 63 72 81 90
package assignments;

public class Question17 {

	public static void main(String[] args) {
		for(int i=9;i<=90;i++) {
			if(i%9==0) {
				System.out.print(" "+ i);
			}
		}
	}

}
