// Write a Program to print 1 to 100 odd number

package assignments;

public class Question3 {

	public static void main(String[] args) {
		
		for(int i=1;i<=100;i++) {
			if(i%2-1==0) {
				System.out.println(i);
			}
		}

	}

}
