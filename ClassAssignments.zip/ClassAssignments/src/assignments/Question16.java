// Generate the series 2 4 6 8 10 12 14 16 18 20

package assignments;

public class Question16 {

	public static void main(String[] args) {
		
		for(int i=2;i<=20;i++) {
			if(i%2==0) {
				System.out.print(" "+ i);
			}
		}
		
	}

}
