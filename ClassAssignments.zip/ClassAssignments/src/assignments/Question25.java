//Generate the series 3 6 9 12 15 18 21 24 27 30
package assignments;

public class Question25 {

	public static void main(String[] args) {
	
		for(int i=3;i<=30;i++) {
			if(i%3==0) {
				System.out.print(" "+i);
			}
		}

	}

}
