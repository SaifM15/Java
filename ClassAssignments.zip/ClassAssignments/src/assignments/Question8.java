// Write a program to print 50 to 100 numbers

package assignments;

public class Question8 {

	public static void main(String[] args) {
		
		for(int i=50; i<=100;i++) {
			System.out.println(i);
		}

	}

}
