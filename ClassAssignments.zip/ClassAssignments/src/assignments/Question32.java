//Write a program to accept a number and find it is odd Number

package assignments;

import java.util.Scanner;

public class Question32 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Number :- ");

		int no = sc.nextInt();
		if (no % 2 != 0) {
			System.out.println(no + " This is Odd number");
		} else {
			System.out.println(no + " This is not Odd Number");
		}

	}
}
