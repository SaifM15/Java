// Write a program to print sum of 1 to 50 odd Numbers

package assignments;

public class Question5 {

	public static void main(String[] args) {

		int sum = 0;

		for (int i = 1; i <= 50; i++) {
			if (i % 2 != 0) {
				sum += i;
			}
			System.out.println("The sum of 1 to 50 odd Numbers "+ sum);

		}
		System.out.println("The sum of 1 to 50 odd Numbers "+ sum);

	}

}
