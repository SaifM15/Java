//Write a program to print count of even number 1 to 25 numbers

package assignments;

public class Question14 {

	public static void main(String[] args) {
		
		int evenCount=0;
		for(int i=1;i<=25;i++) {
			if(i%2==0) {
				evenCount++;
			}
		}
		System.out.println("The Even number Count is"  + evenCount);
	}

}
