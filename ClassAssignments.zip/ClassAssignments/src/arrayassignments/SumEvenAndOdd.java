package arrayassignments;

public class SumEvenAndOdd {
    public static void main(String[] args) {
        int[] numbers = {5, 2, 9, 7, 3, 8, 1, 6};

        int sumEven = 0;
        int sumOdd = 0;

        for (int number : numbers) {
            if (number % 2 == 0) {
                sumEven += number;
            } else {
                sumOdd += number;
            }
        }

        System.out.println("Sum of even numbers: " + sumEven);
        System.out.println("Sum of odd numbers: " + sumOdd);
    }
}
