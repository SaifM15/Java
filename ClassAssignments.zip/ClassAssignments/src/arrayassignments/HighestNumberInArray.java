//Que:- Find Highest number an array

package arrayassignments;

public class HighestNumberInArray {
    public static void main(String[] args) {
        int[] myArray = {5, 12, 8, 27, 15, 3};
        int result = findHighestNumber(myArray);
        System.out.println("The highest number is: " + result);
    }

    public static int findHighestNumber(int[] arr) {
        if (arr.length == 0) {
            return -1; 
        }

        int maxNumber = arr[0]; 

        for (int num : arr) {
            if (num > maxNumber) {
                maxNumber = num; 
            }
        }

        return maxNumber;
    }
}
