package encapsulationpractice;

public class Student {
	private int id;
	private String name;
	private String collegeName;

	void setid(int id) {
		this.id = id;
	}

	public int getid() {
		return id;
	}

	void setname(String name) {
		this.name = name;
	}

	public String getname() {
		return name;
	}

	public String getCollegeName() {
		return collegeName;
	}

	void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public static void main(String[] args) {
		
		Student ss = new Student();
		
		ss.setid(10);
		System.out.println(ss.getid());
		
		ss.setname("JBK");
		System.out.println(ss.getname());
		
		ss.setCollegeName("Zeal");
		System.out.println(ss.getCollegeName());
		

	}

}
