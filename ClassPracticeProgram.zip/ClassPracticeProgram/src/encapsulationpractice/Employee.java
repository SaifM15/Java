package encapsulationpractice;

public class Employee {

	private String name;
	private int employeeId;
	private String companyName;

	void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	void setemployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getemployeeId() {
		return employeeId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public static void main(String[] args) {
		
		Employee e = new Employee();
		
		e.setName("Akash");
		System.out.println("The employee name " + e.getName());
		
		e.setemployeeId(12);
		System.out.println("The employee id " + e.getemployeeId());
		
		e.setCompanyName("Google");
		System.out.println("The employee Company name " +e.getCompanyName());
	}

}
