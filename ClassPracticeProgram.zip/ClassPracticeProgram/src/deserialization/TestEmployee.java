package deserialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestEmployee  {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
	
	File folder= new File("Testing");
	File file= new File(folder,"test.txt");
	FileInputStream fis = new FileInputStream(file);
	ObjectInputStream ois = new ObjectInputStream(fis);
	Employee em=(Employee)ois.readObject();
	
	System.out.println(em.getEid());
	System.out.println(em.getName());
	System.out.println(em.getSalary());
	}
}
