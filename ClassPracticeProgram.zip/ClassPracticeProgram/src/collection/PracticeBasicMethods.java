package collection;

import java.util.ArrayList;
import java.util.List;

public class PracticeBasicMethods {

	public static void main(String[] args) {

		List<String> language = new ArrayList<>();
		language.add("Java");
		language.add("Python");
		language.add("Ruby");
		language.add("CPP");
		language.add("C");
		language.add("JavaScript");

		System.out.println("As it is list " + language);

		System.out.println("Its check the object element is available or not :- " + language.contains("Java"));

		System.out.println("Its check the object element is available or not :- " + language.contains("PHP"));

		System.out.println("check its Empty or not " + language.isEmpty());

		System.out.println(" ");
		
//		language.clear();
//		
//		System.out.println("It is clear all the list " + language);
//		
//		System.out.println("Its check the object element is available or not :- " + language.contains("Java"));
//
//		System.out.println("Its check the object element is available or not :- " + language.contains("PHP"));
//
//		System.out.println("check its Empty or not " + language.isEmpty());
		
		System.out.println("its get Value from List "+ language.get(1));
		System.out.println("Its get value from List "+ language.get(0));
		
		

	}

}
