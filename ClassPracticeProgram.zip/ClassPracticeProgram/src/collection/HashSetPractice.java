package collection;

import java.util.HashSet;
import java.util.Set;

public class HashSetPractice {

	public static void main(String[] args) {

		Set arr = new HashSet<>();
		arr.add(10);
		arr.add(20);
		arr.add(30);
		arr.add(40);
		arr.add(50);
		arr.add("Saif");
		arr.add("Mulla");

		System.out.println("Add Method :- " + arr);

		arr.remove("jbk");
		System.out.println("Remove with Object :- " + arr);

//		arr.removeAll(arr);
//		System.out.println("Remove all the element in Hashset :-"+arr);

		int a = arr.size();
		System.out.println("Size of an Hashset :- " + a);

		boolean aa = arr.isEmpty();
		System.out.println("Check the Hashset is Empty or Not :- " + aa);

//		arr.clear();
//		System.out.println("Clear the Hashset :- "+ arr);

		boolean aaa = arr.contains("TKA");
		System.out.println("Check the Value :- " + aaa);

	}

}
