package collection;

import java.util.List;
import java.util.ArrayList;

public class PracticeAllMethodsWithGenerics {
	public static void main(String[] args) {
//			In that class practice using following methods add(), addAll(), remove(),removeAll() 
		List<String> arr = new ArrayList<>();
		arr.add("Saif");
		arr.add("Mulla");
		arr.add(0, "Mr.");
		System.out.println(arr);

		List<Integer> firstFiveNumbers = new ArrayList<>();
		
		firstFiveNumbers.add(10);
		firstFiveNumbers.add(20);
		firstFiveNumbers.add(30);
		firstFiveNumbers.add(40);
		firstFiveNumbers.add(50);
		
		List<Integer> secondFiveNumber = new ArrayList<>();
		secondFiveNumber.add(60);
		secondFiveNumber.add(70);
		secondFiveNumber.add(80);
		secondFiveNumber.add(90);
		secondFiveNumber.add(100);
		
		List<Integer> TenNumber = new ArrayList<>(firstFiveNumbers);
		TenNumber.addAll(secondFiveNumber);

		
		List<Integer> TenNumber2 = new ArrayList<>(firstFiveNumbers);
		TenNumber2.addAll(1, secondFiveNumber);

		System.out.println("First Five Number :- "+ firstFiveNumbers);
		System.out.println("Second Five Number :- "+ secondFiveNumber);
		System.out.println("Only using Object :- "+ TenNumber);
		System.out.println("Using Index :- "+ TenNumber2);

		boolean a = firstFiveNumbers.addAll(secondFiveNumber);
		boolean aa= secondFiveNumber.addAll(firstFiveNumbers);
		System.out.println("if add then represent true :- "+ a);
		System.out.println("if add then represent true with add all method :- "+ aa);
		
		
		System.out.println(" "  );
		List<String> names=new ArrayList<>();
		names.add("Saif");
		names.add("Sanket");
		names.add("Deva");
		names.add("Akash");
		names.add("Digvijay");
		System.out.println("Print the total names in ArrayList :- "+ names);
		
		names.remove(4);
		
		System.out.println("after removing an element in array list :- "+ names);
		
//		names.removeAll(names);
//		System.out.println("Its remove all element from that list "+ names);
		
		names.remove("Akash");
		System.out.println("Its remove an a object or element is from arraylist :-"+ names);
		
		List<Integer> Number=new ArrayList<>();
		Number.add(1);
		Number.add(2);
		Number.add(3);
		Number.add(4);
		Number.add(5);
		Number.add(6);
		Number.add(7);
		Number.add(8);
		Number.add(9);
		Number.add(10);
		
		System.out.println("Its Print Total Number "+ Number);
		
		List<Integer> OddNumber= new ArrayList<>();
		OddNumber.add(1);
		OddNumber.add(3);
		OddNumber.add(5);
		OddNumber.add(7);
		OddNumber.add(9);
		
		Number.removeAll(OddNumber);
		System.out.println("Its remove all odd Number :-"+ Number);
		
	}
}
