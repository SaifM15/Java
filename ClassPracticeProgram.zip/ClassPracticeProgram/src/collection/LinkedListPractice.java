package collection;


import java.util.LinkedList;
import java.util.List;

public class LinkedListPractice {

	public static void main(String[] args) {
		List arr= new LinkedList<>();
		arr.add(10);
		arr.add(20);
		arr.add(30);
		arr.add(40);
		arr.add(50);
		arr.add("Saif");
		arr.add("Mulla");
		
		System.out.println("Add Method :- " + arr);
		
//		here we are use add(index,object)
		arr.add(7, "jbk");
		arr.add(8, "TKA");
		arr.add(9,"kbj");
		System.out.println("Add Method with Index :- "+ arr);
		
		arr.remove(0);
		System.out.println("Remove Method with Index :- " +arr);
		
		arr.remove("jbk");
		System.out.println("Remove with Object :- " +arr);
		
//		arr.removeAll(arr);
//		System.out.println("Remove all the element in Linkedlist :-"+arr);
		
		int a=arr.size();
		System.out.println("Size of an LinkedList :- "+ a);
		
		boolean aa=arr.isEmpty();
		System.out.println("Check the LinkedList is Empty or Not :- "+ aa);
		
//		arr.clear();
//		System.out.println("Clear the LinkedList :- "+ arr);
		
		boolean aaa=arr.contains("TKA");
		System.out.println("Check the Value :- "+ aaa);
		
	
	
	
	
	
	
	
	
	
	
	
	

	}

}
