package collection;

import java.util.ArrayList;
import java.util.List;

public class ArrayListPractice {

	public static void main(String[] args) {
		
		List arr= new ArrayList<>();
		arr.add(10);
		arr.add(20);
		arr.add(30);
		arr.add(40);
		arr.add(50);
		arr.add("Saif");
		arr.add("Mulla");
		
		System.out.println("Add Method :- " + arr);
		
//		here we are use add(index,object)
		arr.add(7, "jbk");
		arr.add(8, "TKA");
		arr.add(9,"kbj");
		System.out.println("Add Method with Index :- "+ arr);
		
		arr.remove(0);
		System.out.println("Remove Method with Index :- " +arr);
		
		arr.remove("jbk");
		System.out.println("Remove with Object :- " +arr);
		
//		arr.removeAll(arr);
//		System.out.println("Remove all the element in arraylist :-"+arr);
		
		int a=arr.size();
		System.out.println("Size of an ArrayList :- "+ a);
		
		boolean aa=arr.isEmpty();
		System.out.println("Check the ArrayList is Empty or Not :- "+ aa);
		
//		arr.clear();
//		System.out.println("Clear the ArrayList :- "+ arr);
		
		boolean aaa=arr.contains("TKA");
		System.out.println("Check the Value :- "+ aaa);
		
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
