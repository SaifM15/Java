package array;

public class ArrayUses {

	public static void main(String[] args) {

		int arr[] = new int[5];

		arr[1] = 10;
		arr[2] = 20;
		arr[3] = 30;
		arr[4] = 40;

		for (int i = 1; i < arr.length; i++) {
			
			int value = arr[i];
			
			System.out.println(value);
		}

	}

}
