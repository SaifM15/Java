package array;

public class CopyingofArray {

	public static void main(String[] args) {

		int a[] = { 1, 2, 3, 5, 6 };
		int array[] = new int[8];
		System.out.println("Array :::");
		System.out.print("[");

		for (int i = 0; i < a.length; i++) {
			System.out.print(" " + a[i]);

		}
		System.out.print("]");
		System.out.println("\n a:");
		System.out.print("[");
		for (int j = 0; j < a.length; j++) {
			array[j] = a[j];
			System.out.print(" " + array[j]);
		}
		System.out.print("]");
	}

}
