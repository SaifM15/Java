package array;

public class ReverseloopArray {

	public static void main(String[] args) {
	
		boolean[] values= {false,true,true,false,true};
		
		for(int i=values.length-1;i>=0;i--) {
			System.out.println(values[i]);		}
	}

}
