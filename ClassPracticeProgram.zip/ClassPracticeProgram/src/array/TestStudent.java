package array;

public class TestStudent {

	public static void main(String[] args) {

		Student[] arr = new Student[4];

		arr[0] = new Student();
		arr[1] = new Student();
		arr[2] = new Student();
		arr[3] = new Student();

		arr[0].name = "Saif";
		arr[0].surname = "Mulla";
		arr[0].collegeName = "Jbk";
		arr[0].marks = 85.30;

		System.out.println(arr[0].name);
		System.out.println(arr[0].surname);
		System.out.println(arr[0].collegeName);
		System.out.println(arr[0].marks);

		System.out.println(" ");

		arr[1].name = "Jay";
		arr[1].surname = "Tripathi";
		arr[1].collegeName = "JBK";
		arr[1].marks = 88.30;

		System.out.println(arr[1].name);
		System.out.println(arr[1].surname);
		System.out.println(arr[1].collegeName);
		System.out.println(arr[1].marks);

		System.out.println(" ");

		arr[2].name = "Shrdhha";
		arr[2].surname = "Kharade";
		arr[2].collegeName = "JBk";
		arr[2].marks = 65.00;

		System.out.println(arr[2].name);
		System.out.println(arr[2].surname);
		System.out.println(arr[2].collegeName);
		System.out.println(arr[2].marks);

		System.out.println(" ");

		arr[3].name = "Sagar";
		arr[3].surname = "Patil";
		arr[3].collegeName = "JBk";
		arr[3].marks = 75.00;

		System.out.println(arr[3].name);
		System.out.println(arr[3].surname);
		System.out.println(arr[3].collegeName);
		System.out.println(arr[3].marks);

		System.out.println(" ");
		
		for(int i=0;i<=3;i++) {
			System.out.println(arr[i].name);
			System.out.println(arr[i].surname);
			System.out.println(arr[i].collegeName);
			System.out.println(arr[i].marks);
			System.out.println(" ");
		}
	}

}
