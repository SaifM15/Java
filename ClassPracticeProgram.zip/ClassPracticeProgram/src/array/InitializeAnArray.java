package array;

public class InitializeAnArray {

	public static void main(String[] args) {
		
		int []array= {1,3,5};
		String [] array1= {"Dog","Animal","Cat"};
		
		System.out.println("It is length of Array " + array.length);
		System.out.println("It is length of Array1 " + array1.length);
		
		System.out.println("Here we can Initialise " + array[2]);
		System.out.println("Here we can Initialise array 1" + array1[2]);

	}

}
