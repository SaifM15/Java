package array;

public class LengthOfArray {

	public static void main(String[] args) {

		int a[] = new int[3];
		a[0]=10;
		int a1[] = { 3, 5, 4, 6, 8, 7, 9 };
		int a2[] = { 4, 3, 2, 1 };

		System.out.println(a.length);
		System.out.println(a1.length);
		System.out.println(a2.length);
		System.out.println(a2);
	}

}
