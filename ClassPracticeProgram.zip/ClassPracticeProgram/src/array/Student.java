package array;

public class Student {
	String name;
	Double marks;
	String surname;
	String collegeName;
	

}
