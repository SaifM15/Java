package array;

public class ArrayEqualTest {

	public static void main(String[] args) {

		int array1[] = { 1, 2, 3, 4 };
		int array2[] = { 1, 2, 3, 4 };

		if (array1 == array2) {
			System.out.println("This is Same");
		} else {
			System.out.println("This is Different");
		}
	}

}
