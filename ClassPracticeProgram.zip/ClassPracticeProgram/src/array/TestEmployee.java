package array;

public class TestEmployee {

	public static void main(String[] args) {

		Employee[] emp = new Employee[3];

		emp[0] = new Employee();
		emp[1] = new Employee();
		emp[2] = new Employee();

		emp[0].employeeName = "Jay";
		emp[0].employeeSurname = "Tripathi";
		emp[0].id = 10;

		System.out.println("Employee name " + emp[0].employeeName);
		System.out.println(emp[0].employeeSurname);
		System.out.println(emp[0].id);
		System.out.println(" ");
		
		emp[1].employeeName = "Sagar";
		emp[1].employeeSurname = "Patil";
		emp[1].id = 11;

		System.out.println("Employee name " + emp[1].employeeName);
		System.out.println(emp[1].employeeSurname);
		System.out.println(emp[1].id);
		System.out.println(" ");
		
		emp[2].employeeName = "Tejas";
		emp[2].employeeSurname = "kale";
		emp[2].id = 12;

		System.out.println("Employee name " + emp[2].employeeName);
		System.out.println(emp[2].employeeSurname);
		System.out.println(emp[2].id);

	}

}
