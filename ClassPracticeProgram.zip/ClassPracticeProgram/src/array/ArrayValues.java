package array;

public class ArrayValues {

	public static void main(String[] args) {
		
		int [][] values= {{1,2},{3,4}};
//		0   1
//	0	1   2
//	1	3   4
		System.out.println(values[0][0]);
		System.out.println(values[1][0]);
		System.out.println(values[0][1]);
		System.out.println(values[1][1]);
	}

}
