package array;

import java.util.Scanner;

public class UserInputArray {

	public static void main(String[] args) {
		
		int []z=new int[10];
		
		Scanner sc =new Scanner(System.in);
		
		for(int i=0;i<10;i++) {
			System.out.println("Enter the array element");
			z[i]=sc.nextInt();		
			}
		System.out.println("You have entered");
		for(int i=0;i<10;i++) {
			System.out.println(z[i]);
		}
	}

}
