package array;

public class DisplayDeclaredArray {

	public static void main(String[] args) {

		int a[]= {10,20,30,40,50};
		for(int i=0;i<a.length;i++) {
			System.out.println("The List is " + a[i]);
		}
	}

}
