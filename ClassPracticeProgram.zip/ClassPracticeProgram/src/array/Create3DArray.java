package array;

public class Create3DArray {

	public static void main(String[] args) {

		byte space[][][] = new byte[3][2][3];
		
		space[0][0][0]=10;
		space[1][1][1]=20;
		space[2][0][2]=30;	
		
		System.out.println(space[0][0][0]);
		System.out.println(space[1][1][1]);
		System.out.println(space[2][0][2]);
	}

}
