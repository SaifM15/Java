package array;
import java.util.Arrays;
public class MergeTwoArray {

	public static void main(String[] args) {

		int array[] = { 10, 20, 30, 40 };
		int array1[] = { 100, 200, 300, 400 };

		int[] merge = new int[array.length + array1.length];
		for (int i = 0; i < array.length; i++) {
			merge[i] = array[i];
		}
		for(int i=0;i<array1.length;i++) {
			merge[i+array.length]=array1[i];
		}
		System.out.println(Arrays.toString(merge));
	}

}
