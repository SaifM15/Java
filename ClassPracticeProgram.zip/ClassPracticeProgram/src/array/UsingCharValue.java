package array;

public class UsingCharValue {

	public static void main(String[] args) {
	
		char[] value= new char[3];
		
		value[0]='J';
		value[1]='B';
		value[2]='K';
		
		for(char Values:value) {
			System.out.print(Values);
		}
	}

}
