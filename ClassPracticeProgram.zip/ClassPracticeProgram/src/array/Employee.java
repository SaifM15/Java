package array;

public class Employee {
	
	int id;
	String employeeName;
	String employeeSurname;
	
	
}
