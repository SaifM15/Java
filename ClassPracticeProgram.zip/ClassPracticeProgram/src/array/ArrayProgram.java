// Program for declare, initialize, and display array

package array;

public class ArrayProgram {

	public static void main(String[] args) {
		
		int a[] =new int[5];
		a[0]=10;
		a[1]=20;
		a[2]=50;
		a[3]=70;
		a[4]=90;
		
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
		
				

	}

}
