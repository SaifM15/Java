package synchronization;

public class Counter {
	
	public static int count=0;
	
	public synchronized static void increment() {
		
		count =count+1;
		
	}

}
