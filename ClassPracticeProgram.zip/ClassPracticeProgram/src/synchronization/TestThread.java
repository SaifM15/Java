package synchronization;

public class TestThread {
	
	public static void main(String[] args) {
		
		Thread1 t1= new Thread1();
		t1.start();
		
		Thread2 t2= new Thread2();
		t2.start();
		try {
			t1.join();
			t2.join();
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println(Counter.count);
	}

}
