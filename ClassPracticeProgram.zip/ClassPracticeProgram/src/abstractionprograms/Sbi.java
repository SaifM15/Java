package abstractionprograms;

public class Sbi extends Rbi{
	
	@Override
	public void takeInterest() {
		System.out.println("9%");
	}
	
	@Override
	public void openAccount() {
		System.out.println("500 rs charges");
	}
	
		
	
}
