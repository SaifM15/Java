package abstractionprograms;

public class Cbi extends Rbi {
	

	@Override
	public void takeInterest() {
		System.out.println("15%");
	}
	
	@Override
	public void openAccount() {
		System.out.println("Free of Cost");
	}
	
}
