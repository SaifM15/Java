package abstractionprograms;

public class TestRbi {

	public static void main(String[] args) {
		
		Cbi c = new Cbi();
		c.openAccount();
		c.takeInterest();
		
		Sbi s = new Sbi();
		s.openAccount();
		s.takeInterest();
	}

}
