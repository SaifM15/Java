package abstractionprograms;

public abstract class Rbi {
	public abstract void takeInterest();
	public abstract void openAccount();
}
