package interfaceprograms;

public class Sbi implements Rbi{
	
	public void interest() {
		System.out.println("9%");
	}
	public void openAccount() {
		System.out.println("Free");
	}
	
	

}
