package interfaceprograms;

public class Cbi implements Rbi{
	public void interest() {
		System.out.println("20%");
	}
	public void openAccount() {
		System.out.println("500 rs Charges");
	}

}
