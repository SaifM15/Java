package interfaceprograms;

public class TestRbi {

	public static void main(String[] args) {
		
		Sbi s= new Sbi();
		s.openAccount();
		s.interest();
		
		System.out.println(" ");
		
		Cbi c= new Cbi();
		c.openAccount();
		c.interest();
	}

}
