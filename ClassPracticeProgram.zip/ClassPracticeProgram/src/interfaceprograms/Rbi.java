package interfaceprograms;

 interface Rbi {
	abstract void openAccount();
	abstract void interest();
}
