package com.classpracticeprogram;

public class PrintVariableValue {

	public static void main(String[] args) {
		
		int distance=25;
		System.out.println(distance);

	}

}
