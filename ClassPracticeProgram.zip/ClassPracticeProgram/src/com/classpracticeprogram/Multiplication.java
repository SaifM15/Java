package com.classpracticeprogram;

import java.util.Scanner;

public class Multiplication {

	public static void main(String[] args) {
		 Scanner sc= new Scanner(System.in);
		 
		 System.out.println("Enter the first number");
		 double a =sc.nextDouble();
		 
		 System.out.println("Enter the Second Number");
		 double b= sc.nextDouble();
		 
		 double multiplication=a*b;
		 System.out.println("The Multiplication of two number is " +multiplication);
	}

}
