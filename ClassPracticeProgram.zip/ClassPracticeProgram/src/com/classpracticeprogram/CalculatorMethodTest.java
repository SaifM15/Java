package com.classpracticeprogram;

public class CalculatorMethodTest {

	public static void main(String[] args) {

		CalculatorMethod cm = new CalculatorMethod();
		int mulresult = cm.mul();
		System.out.println("The Multiplication of Two Number is "+mulresult);

		int resultt = CalculatorMethod.add();

		System.out.println("The Addition is two value are " + resultt);
	}

}
