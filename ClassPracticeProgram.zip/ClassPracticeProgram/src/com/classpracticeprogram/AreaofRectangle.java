package com.classpracticeprogram;

public class AreaofRectangle {

	public static void main(String[] args) {

		int side = 10;
		int length = 20;
		int area = side * length;

		System.out.println(area);

	}

}
