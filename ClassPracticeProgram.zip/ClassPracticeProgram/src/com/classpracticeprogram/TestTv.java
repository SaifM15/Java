package com.classpracticeprogram;

public class TestTv {

	public static void main(String[] args) {
		
		System.out.println("1");
		
		Tv tv= new Tv();
		
		tv.on();
		int x=tv.channel(125);
		System.out.println(x);
		
		tv.IncreaseVolume();
		tv.DecreseVolume();
		tv.off();
		
		System.out.println("2");
		

	}

}
