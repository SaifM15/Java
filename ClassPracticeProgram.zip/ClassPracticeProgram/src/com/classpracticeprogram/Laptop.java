package com.classpracticeprogram;

public class Laptop {
	String brandname;
	int price;
	int rom;
	String Processsor;
	
	void on() {
		System.out.println("Fan is On");
	}
	void off() {
		System.out.println("Fan is Off");
	}
	void moveable() {
		System.out.println("we can move laptop");
	}

}
