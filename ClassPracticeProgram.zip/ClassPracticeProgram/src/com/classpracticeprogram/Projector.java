package com.classpracticeprogram;

public class Projector {
//	Design an Object
	
//	has-part
	String Brandname;
	String color;
	double price;
//	does part
	
	void display() {
		System.out.println("Displaying Screen");
		
	}
	void zoomin() {
		System.out.println("Zoom in");
	}
	
	void zoomout() {
		System.out.println("Zoom out");
	}

}
