package com.classpracticeprogram;
import java.util.Scanner;
public class AreaOfCircle2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		double pi=3.14;
		System.out.println("Enter the Radius");
		double r=sc.nextDouble();
		
		double area=pi*r*r;
		
		System.out.println("The Radius is " + area);
		
	}

}
