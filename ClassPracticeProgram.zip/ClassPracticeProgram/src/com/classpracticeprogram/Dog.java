package com.classpracticeprogram;

public class Dog {
	String name;
	int age;
	String color;
	void walking() {
		System.out.println("Dog is Walking");
		
	}
	void eating () {
		System.out.println("Dog id Eating");
		
	}
	void running() {
		System.out.println("Dog is running");
		
	}

}
