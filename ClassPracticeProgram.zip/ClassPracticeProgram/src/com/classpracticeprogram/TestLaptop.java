package com.classpracticeprogram;

public class TestLaptop {

	public static void main(String[] args) {
		
		Laptop l= new Laptop();
		l.on();
		l.off();
		l.moveable();

	}

}
