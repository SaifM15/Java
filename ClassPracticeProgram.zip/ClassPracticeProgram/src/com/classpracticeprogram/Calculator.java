package com.classpracticeprogram;

public class Calculator {

	public static void main(String[] args) {
		
		int A=100;
		int B=20;
		System.out.println(A+B);
		System.out.println(A-B);
		System.out.println(A*B);
		System.out.println(A/B);
	}

}
