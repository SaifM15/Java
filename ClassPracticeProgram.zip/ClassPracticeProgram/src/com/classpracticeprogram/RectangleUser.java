package com.classpracticeprogram;

import java.util.Scanner;

public class RectangleUser {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Side :-");
		double side=sc.nextDouble();
		
		System.out.println("Enter the Length :-");
		double length=sc.nextDouble();
		
		double areaofRectangle =side*length;
		
		System.out.println("The Area Of Rectangle is " +areaofRectangle);
	}

}
