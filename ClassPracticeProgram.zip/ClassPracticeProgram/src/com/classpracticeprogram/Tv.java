package com.classpracticeprogram;

public class Tv {
	
//	has part
	String Brandname;
	String Color;
	double price;
	
//	Does-part
	
	void on() {
		System.out.println("Tv is Start"); 
	}

	int channel(int choice) {
		System.out.println("your choice channel is"+choice);
		return choice;
	}
	void IncreaseVolume() {
		System.out.println("Volume++");
	}
	void DecreseVolume() {
		System.out.println("Volume--");
	}
	void off() {
		System.out.println("Tv is Off");
	}
	
	
}
