package com.classpracticeprogram;

public class TestChair {

	public static void main(String[] args) {
		
	Chair c= new Chair();
	c.down();
	c.up();
	c.moving();
	}

}
