package com.classpracticeprogram;

public class Construtor {
	int id;
	String name;
	 Construtor(int id,String name){
		 this.id=id;
		 this.name=name;
	 }

	public static void main(String[] args) {
		
		Construtor c=new Construtor(1,"Saif");
		
		System.out.println("The Employee id is " +c.id+ " The Employee name is " +c.name);

	}

}
