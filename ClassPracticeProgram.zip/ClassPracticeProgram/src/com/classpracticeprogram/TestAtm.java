package com.classpracticeprogram;

public class TestAtm {

	public static void main(String[] args) {
	
		Atm A= new Atm();
		int amo=A.withdraw(500);
		System.out.println(amo);
	}

}
