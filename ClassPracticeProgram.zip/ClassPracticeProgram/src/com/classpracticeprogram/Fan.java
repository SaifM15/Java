package com.classpracticeprogram;

public class Fan {
	String brandname;
	String ModelName;
	int price;
	
	void Speed() {
		System.out.println("Speed");
	}
	void increase() {
		System.out.println("we can increase speed");
	}
	void decrease() {
		System.out.println("we can decrese speed of fan");
	}

}
