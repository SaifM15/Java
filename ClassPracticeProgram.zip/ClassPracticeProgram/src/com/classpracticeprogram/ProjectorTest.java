package com.classpracticeprogram;

public class ProjectorTest {

	public static void main(String[] args) {
		
		Projector p= new Projector();
		p.display();
		p.zoomin();
		p.zoomout();
		
		Projector p1= new Projector();
		p.display();
		p.zoomin();
		p.zoomout();
		
		
//		create an object and testing functionality of an object
	}

}
