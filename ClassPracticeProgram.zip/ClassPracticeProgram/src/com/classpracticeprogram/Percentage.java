package com.classpracticeprogram;

import java.util.Scanner;

public class Percentage {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your Marks");
		int math=sc.nextInt();
		int physics=sc.nextInt();
		int chem=sc.nextInt();
		int bio=sc.nextInt();
		int english=sc.nextInt();
		
		double percentage=(math+physics+chem+bio+english)*100/500;
		
		System.out.println(percentage);
		
		
		
	}

	
}
