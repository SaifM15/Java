package com.classpracticeprogram;

public class Chair {
	String Brandname;
	int Wheels;
	String color;
	int price;
	
	void moving() {
		System.out.println("We can move chair");
	}
	 void up() {
		 System.out.println("we can up chair");
	 }
	 void down() {
		 System.out.println("we can down chair");
	 }
}
