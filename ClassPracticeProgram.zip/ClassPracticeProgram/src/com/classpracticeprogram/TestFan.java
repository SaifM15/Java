package com.classpracticeprogram;

public class TestFan {

	public static void main(String[] args) {
		
		Fan f= new Fan();
		f.Speed();
		f.increase();
		f.decrease();

	}

}
