package com.classpracticeprogram;

public class DogTest {

	public static void main(String[] args) {
		Dog d= new Dog();
		d.running();
		d.walking();
		d.eating();

	}

}
