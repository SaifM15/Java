package com.classpracticeprogram;

import java.util.Scanner;

public class DiscountCalculation {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the original Price");
		int originalprice = sc.nextInt();
		System.out.println("Enter the  Percentage");
		int percentage = sc.nextInt();
		int discount = originalprice * percentage / 100;

		int sellingprice = originalprice - discount;

		System.out.println("The original Price is " + originalprice);
		System.out.println("The Discount is " + discount);
		System.out.println("The selling Price is " + sellingprice);
	}

}
