package com.classpracticeprogram;

import java.util.Scanner;

public class Atm {
	Scanner sc =new Scanner(System.in);
	
	int withdraw(int amount) {
		int amountt =5000;
		
		return amount;
	}
	
}
