package com.classpracticeprogram;

import java.util.Scanner;

public class CalculatorMethod {
	static Scanner sc = new Scanner(System.in);
	 int mul() {
		System.out.println("Enter your amount for A");
		int a=sc.nextInt();
		System.out.println("Enter your amount for B");
		int b=sc.nextInt();
	
		int result=a*b;
		return result;
	}
	 
	 
	static int add() {
		System.out.println("Enter your amount for A");
		int a=sc.nextInt();
		System.out.println("Enter your amount for B");
		int b=sc.nextInt();
	
		int result=a+b;
		return result;
	}
}
