package inheritancepractice;
class AAA{
	void AAA() {
		System.out.println("This is AAA Method");
	}
}
class BBB extends AAA{
	void BBB() {
		System.out.println("This is BBB Method");
	}
}

class CCC extends AAA{
	void CCC() {
		System.out.println("This is CCC Method");
	}
}

class DDD extends AAA{
	void DDD() {
		System.out.println("This is DDD Method");
	}
}
public class HierachycalInheritance {

	public static void main(String[] args) {

		AAA a= new AAA();
		a.AAA();
		
		BBB b= new BBB();
		b.BBB();
		
		CCC c = new CCC();
		c.CCC();
		
		DDD d = new DDD();
		d.DDD();
	}

}
