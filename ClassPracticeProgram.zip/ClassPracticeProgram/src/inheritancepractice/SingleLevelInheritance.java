package inheritancepractice;

class A{
	void m1() {
		System.out.println("This is A Method");
	}
}

class B extends A{
	void m2() {
		System.out.println("This is B Method");
	}
}

public class SingleLevelInheritance {

	public static void main(String[] args) {
		B b= new B();
		b.m1();
		b.m2();

	}

}
