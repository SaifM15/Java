package inheritancepractice;

class AA{
	void n() {
		System.out.println("This is AA Method");
	}
}
class BB extends AA{
	void n1() {
		System.out.println("This is BB Method");
	}
}
class CC extends BB{
	void n2() {
		System.out.println("This is CC Method");
	}
}

public class MultilevelInheritance {

	public static void main(String[] args) {
		
		CC cc = new CC();
		cc.n();
		cc.n1();
		cc.n2();
		// TODO Auto-generated method stub

	}

}
