package serialization;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestEmployee {
	public static void main(String[] args) throws IOException {
		
		
//		File ff = new File("TestFile");
//		System.out.println(ff.getAbsoluteFile());
//		boolean isCreted=ff.mkdir();
//		System.out.println(isCreted);
		
//		File file = new File(ff,"TestDoc.txt");
//		System.out.println(file.getAbsolutePath());
//		boolean isCreated = file.createNewFile();
//		System.out.println(isCreated);
		
//		FileWriter filewriter= new FileWriter(file);
//		filewriter.write("Saif Mulla");
//		filewriter.close();
//		System.out.println("Data is Stored");
		
		
		
		Employee em= new Employee("Saif",10,450);
		
		File folder= new File("Testing");
//		boolean isCreated=folder.mkdir();
//		System.out.println(isCreated);
		
		File file= new File(folder,"test.txt");
//		file.createNewFile();

		
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(em);
		
		oos.flush();
		fos.close();
		
		System.out.println("Object Stored to file");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
