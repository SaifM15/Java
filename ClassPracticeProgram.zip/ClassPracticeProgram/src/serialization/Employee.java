package serialization;

import java.io.Serializable;

public class Employee implements Serializable {

	private String name;
	private int eid;
	private int salary;

	public Employee() {
		super();
	}
	
	public Employee(String name,int eid,int salary) {
		super();
		this.eid=eid;
		this.name=name;
		this.salary=salary;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getEid() {
		return eid;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getSalary() {
		return salary;
	}
}
