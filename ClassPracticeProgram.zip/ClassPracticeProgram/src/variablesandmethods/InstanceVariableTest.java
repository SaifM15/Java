package variablesandmethods;

public class InstanceVariableTest {
	 void m1() {
		 InstanceVariable IV= new InstanceVariable();
		 System.out.println(IV.x);
		}
	 static String m2(String a) {
	
		 InstanceVariable IV2 = new InstanceVariable();
		
		 System.out.println(IV2.s);
		 return  a;
	 }


	public static void main(String[] args) {
		
		InstanceVariableTest iv = new InstanceVariableTest();
		 iv.m1();
		 
		 
		 String a=InstanceVariableTest.m2("Saif");
		 System.out.println(a);
	
		 
	}

}
