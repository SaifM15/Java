package variablesandmethods;

public class LocalVariable {

	void m1() {
		int rollno = 10;
		String name = "Saif";
		double marks = 87.07;
		System.out.println(rollno);
		System.out.println(name);
		System.out.println(marks);
	}

	public static void main(String[] args) {
		
		LocalVariable LV = new LocalVariable();
		LV.m1();

	}

}
