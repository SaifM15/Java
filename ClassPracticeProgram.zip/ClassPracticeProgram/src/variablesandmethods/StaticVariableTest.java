package variablesandmethods;

public class StaticVariableTest {
	
	void m1()
	{
		System.out.println(StaticVariable.y);
	}
	static void  m2() {
		System.out.println(StaticVariable.x);
		System.out.println(StaticVariable.y);
	}
	public static void main(String[] args) {
		
		StaticVariableTest SV= new StaticVariableTest();
		SV.m1();
		StaticVariableTest.m2();
		
				
		
	}

}
