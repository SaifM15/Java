package variablesandmethods;
 class InstanceVariable {
	int x=10;
	String s="xyz";
	char c;
}
