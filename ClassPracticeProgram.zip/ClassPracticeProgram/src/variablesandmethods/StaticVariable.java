package variablesandmethods;

public class StaticVariable {
	static int x=20;
	static String y="10";
	static char z;
	static double p;
	
	
}
