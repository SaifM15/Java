package variablesandmethods;

public class Temp {
    public static void main(String[] args) {
        int rows = 4;  

        for (int i = 10; i <= 16; i += 2) {
            for (int j = i; j <= i + 6; j += 2) {
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }
}