package string;

public class StringToIntegerWithoutInbuiltFunction {

	public static void main(String[] args) {
		
		String str=new String("10");
		
		int i=Integer.parseInt(str);
		System.out.println(i);

	}

}
