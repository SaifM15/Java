package string;

public class AllStringMethods {

	public static void main(String[] args) {

		String s = "The Kiran Academy";
		System.out.println("1. "+ s);
		
		String s1 = new String("Hello");
		System.out.println("2. "+ s1);
		
//		return the total length number of String referenceName.length()
		int value=s.length();
		System.out.println("3. "+value);
		
//		return the total length number of String referenceName.length()
		int value2=s1.length();
		System.out.println("4. "+value2);
		
//		return the UpperCase String in Lowercase referenceName.toLowerCase()
		String tka="THE KIRAN ACADEMY";
		String Lowercase=tka.toLowerCase();
		System.out.println("5. "+ Lowercase);
		
//		return the Lowercase String in Uppercase referenceName.toUpperCase()
		String TKA= "the kiran Academy";
		String Uppercase=TKA.toUpperCase();
		System.out.println("6. "+Uppercase);
		
//		return the original String without an blank spaces referenceName.trim()
		String name1="              Saif Mulla          ";
		System.out.println("7. "+name1.trim());
		
//		return the jo number dila tith prayant cut karun tyachya pudhchi string print hoil
		String name2="Java By Kiran";
		System.out.println("8. "+name2.substring(8));
		
//		return the start number pasun te jo number dilay tyachya mage ek character print karte
		String name3="The Kiran Academy";
		System.out.println("9. "+ name3.substring(2, 10));
		
//		replace the character with which you provide character 
		String name4="Harry";
		System.out.println("10. "+ name4.replace('r', 'p'));
		
//		replace the substring to the you provided substring
		String name5="Harry";
		System.out.println("11. "+ name5.replace("Ha", "hair"));
		
//		check the prefix of the string is same of given in parameteres is give true not same then false
		String name6="Hello";
		System.out.println("12. "+ name6.startsWith("He"));
		
//		check suffix is match in given parameters then give result true or not match then false
		String name7="Harry";
		System.out.println("13. "+name7.endsWith("ry"));
		
//		give the character you provide the index in parameters
		String name8="Hello";
		System.out.println("14. "+name8.charAt(1));

//		return the value of String character you pass in the parameter
		String name9="hello";
		System.out.println("15. "+name9.indexOf("e"));
		
//		return the value of String you search and integer value is for tya number chya pudhe
		String name10="harryrry";
		System.out.println("16. "+name10.indexOf("y", 6) );
		
//		return  last value of index you search in from parameters 
		System.out.println("17. "+name10.lastIndexOf("r"));
		
//		return the value of index counting from last given the number
		System.out.println("17. "+name10.lastIndexOf("r", 5));
	
//		it is check the string value is correct then output is true or not correct false
		String nam1="Saif";
		System.out.println("18. "+nam1.equals("saif"));
		
		System.out.println("19. "+nam1.equalsIgnoreCase("Saif"));
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
