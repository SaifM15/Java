package string;

public class RemoveAnAlphabet {

	public static void main(String[] args) {
		
		String s="The Kiran Academy";
		
		String r[]=s.split("K|i|T");
		
		String res="";
		
		for(String m:r) {
			res=res+m;
		}
		System.out.println(res);
		
	}

}
