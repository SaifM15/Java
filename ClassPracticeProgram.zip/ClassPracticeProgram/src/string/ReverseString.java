package string;

public class ReverseString {

	public static void main(String[] args) {
	
		String s="The Kiran Academy";
		
		char c[]=new char [s.length()];	
		
		int n=s.length()-1;
		
		for(int i=0;i<s.length();i++) {
			c[i]=s.charAt(n);
			n--;
		}
		String rev = new String (c);
		System.out.println(rev);
		
	}

}
