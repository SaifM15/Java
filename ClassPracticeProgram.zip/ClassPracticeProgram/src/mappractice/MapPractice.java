package mappractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapPractice {
	
	public static void main(String[] args) {

		Map<Integer ,String> StudentData= new HashMap<>();
		StudentData.put(11, "Saif");
		StudentData.put(22, "Jay");
		StudentData.put(33, "Sanket");
		StudentData.put(44, "Shrdhaa");
		StudentData.put(55, "Tararani");
		StudentData.put(66, "Tejas");
		StudentData.put(77, "Manoj");
		StudentData.put(88, "Sagar");
		
		System.out.println(StudentData);
		
		System.out.println("Its print the given key data :- "+ StudentData.get(11));
		System.out.println(StudentData.get(33));
		System.out.println(StudentData.get(66));
		System.out.println(StudentData.get(77));
		
		System.out.println(" ");
		
		System.out.println("check the key is available or not :- "+StudentData.containsKey(22));
	
		System.out.println("Check the Contains value are availble :- "+ StudentData.containsValue("Jay"));
	
		System.out.println("Check the Size of Map key Pair :- "+ StudentData.size());
	
		System.out.println("Check the Map is Empty or not :- "+ StudentData.isEmpty());
		
//		StudentData.clear();
//		System.out.println("Its indicates the clear method clear all data inside the map "+ StudentData);
		
		System.out.println("It is represent the key available in the map :- "+ StudentData.keySet());
		
		StudentData.remove(77);
		System.out.println(StudentData);
		
		Set<Integer> keys=  StudentData.keySet();
		System.out.println(keys);
		
		for(Integer key:keys) {
			System.out.println(key +"--->"+StudentData.get(key));
		}
		
		
		
		
		
		
		
		
		
	}
}
