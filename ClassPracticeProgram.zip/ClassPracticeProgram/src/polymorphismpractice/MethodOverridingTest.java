package polymorphismpractice;

public class MethodOverridingTest extends MethodOverriding{
	void A1() {
		System.out.println("This is Updated Method A1");
	}
	
	void A2() {
		System.out.println("This is Updated Method A2");
	}
	public static void main(String[] args) {
		
		MethodOverridingTest mot = new MethodOverridingTest();
		mot.A1();
		mot.A2();
		mot.A3();

	}

}
