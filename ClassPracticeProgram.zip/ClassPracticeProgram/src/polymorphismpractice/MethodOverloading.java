package polymorphismpractice;

public class MethodOverloading {
	
	void m1() {
		System.out.println("first Method");
	}
	
	void m1(int a) {
		System.out.println("This is a Second method");
	}
	
	void m1(String a) {
		System.out.println("Last Method");
	}
	public static void main(String[] args) {
		MethodOverloading mo = new MethodOverloading();
		mo.m1();
		mo.m1(10);
		mo.m1("JBK");
	}

}
