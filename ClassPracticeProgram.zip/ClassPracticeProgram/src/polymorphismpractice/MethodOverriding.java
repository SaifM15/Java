package polymorphismpractice;

public class MethodOverriding {
	
	void A1() {
		System.out.println("This is A1 Method");
	}
	
	void A2() {
		System.out.println("This is A2 Method");
	}
	
	void A3() {
		System.out.println("This is A3 Method");
	}
}
