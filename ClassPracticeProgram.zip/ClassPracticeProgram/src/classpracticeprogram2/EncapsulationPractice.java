package classpracticeprogram2;

public class EncapsulationPractice {
	
	private int id;
	private String name;
	
	public int setid(int id) {
		return this.id=id;
		
	}
	
	public int getid() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String setName(String name) {
		return this.name = name;
	}

	public static void main(String[] args) {
		
		EncapsulationPractice ep = new EncapsulationPractice();
		
		ep.getid();
		System.out.println(ep.setid(11)); 
		ep.getName();
		System.out.println(ep.setName("Deva"));;
	}

}
