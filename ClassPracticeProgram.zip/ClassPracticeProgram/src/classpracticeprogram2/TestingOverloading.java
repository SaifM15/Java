package classpracticeprogram2;

public class TestingOverloading {

	public static void main(String[] args) {
		
		MethodOverloading MO = new MethodOverloading();
		MO.display();
		MO.display(10);

	}

}
