package classpracticeprogram2;

public class UserInput {
	
	String display(String a) {
		System.out.println("1");
		return a;
	}

	public static void main(String[] args) {
		
		UserInput ui = new UserInput();
		String b=ui.display("Sahil");
		
		System.out.println(b);
		
		
	}

}
