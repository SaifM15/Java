package classpracticeprogram2;

public class MethodOverloading {
	
	void display() {
		System.out.println("This is Display Method");
	}
	void display(int a) {
		System.out.println("This is second Display Method");
	}



	}


