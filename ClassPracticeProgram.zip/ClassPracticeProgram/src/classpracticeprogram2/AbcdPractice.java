package classpracticeprogram2;

public class AbcdPractice {

	public static void main(String[] args) {
		
		int Alp=65;
		for(int i=0;i<=25;i++) {
			
			System.out.print((char)(Alp+i)+ " ");
		}
	}

}
