package classprogram;

public class PanCard {
	
	String name;
	String dob;
	String address;
	String panNumber;
	

}
