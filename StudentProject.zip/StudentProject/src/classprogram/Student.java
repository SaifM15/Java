package classprogram;

public class Student {
	
	String name;
	int age;
	String address;
	PanCard pancard;
	AdharCard adharcard;
	
	void introduce() {
		System.out.println("The Student name is " + name);
		System.out.println("The age is " + age );
		System.out.println("The address is "+ address);
		
		System.out.println("The Pan address is " + pancard);
		System.out.println("The Pan Name is " + pancard.name);
		System.out.println("The dob is " + pancard.dob);
		System.out.println("The address is " + pancard.panNumber);
		
		System.out.println("The Adhar Memory Address is " + adharcard);
		System.out.println("The Adhar name is " + adharcard.name);
		System.out.println("The Adhar dob is " + adharcard.dob);
		System.out.println("The Adhar Address is" + adharcard.address);
		System.out.println("The Adhar Number is" + adharcard.adharNumber);
	}

}
