package classprogram;

public class TestStudent {

	public static void main(String[] args) {
		
		PanCard pan= new PanCard();
		pan.name="Deva";
		pan.dob="10/10/23";
		pan.address="Nashik";
		pan.panNumber="GL4566";
		
		AdharCard adhar= new AdharCard();
		adhar.name="Deva";
		adhar.dob="10/10/23";
		adhar.address="Nashik";
		adhar.adharNumber=123456789;
		
		Student s = new Student();
		s.name="Deva";
		s.age= 25;
		s.address="Nashik";
		s.pancard=pan;
		s.adharcard=adhar;
		s.introduce();
		

	}

}
