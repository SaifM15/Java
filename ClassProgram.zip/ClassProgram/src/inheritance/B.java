package inheritance;

public class B {
	void m2() {
		System.out.println("Hello World");
	}

	void m3() {
		System.out.println("New methods");
	}

	public static void main(String[] args) {

		A b = new A();
		A b1= new A();
		A bb= new A();

		int one = b.hashCode();
		System.out.println("one " +one);
		int two =b.hashCode();
		System.out.println("Two " +two);
		int three =b.hashCode();
		System.out.println("Three " + three);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		System.out.println("HashCode Method " +B);
		
//		 a=b.getClass();
//		
//		String name= a.getname();
//		System.out.println(name);
		
//		String k=b.toString();
//		System.out.println("toString Method " +k);
		
//		b.finalize();
//		b.notify();
//		b.notifyAll();
//		b.wait();
		
	}

}
