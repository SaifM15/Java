package inheritance;

public class BBB extends AAA {
	
	
	

	public static void main(String[] args) {
		
		BBB b =new BBB();
		

	}

}
