package inheritance;

public class A {
	void m1() {
		
	}

}
