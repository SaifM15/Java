package inheritance;

public class AAA {
	
	AAA(){
		System.out.println("AAA");
	}
	

}
