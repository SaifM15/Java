package classprogram;

public class AdharCard {
	
	String name;
	String dob;
	String address;
	int adharNumber;
	

}
