package revision;

public class Product {
	String brandName;
	String color;
	String ram;
	String romStorage;
	String display;
	String camera;
	int originalprice;
	 int percentage;
	
	void displayproduct() {
		System.out.println("The brand name is " +brandName);
		System.out.println("The color is " + color);
		System.out.println("The Ram is " + ram);
		System.out.println("The Storage is " + romStorage);
		System.out.println("Display is "+ display);
		System.out.println("camera is " + camera);
	}
	 int discout() {
		
		 int discount=originalprice *percentage/100;
		 System.out.println("The discount is " + discount);
		 
		 int sellingPrice= originalprice-discount;
		 return sellingPrice;
//		 System.out.println(sellingPrice);
	 }
	
}
