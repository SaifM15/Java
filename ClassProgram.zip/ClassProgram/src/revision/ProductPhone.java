package revision;

public class ProductPhone {
	String brandName;
	String color;
	int ram;
	int originalPrice;
	int discountPercentage;
	
	void setvalueInstanceVariable(String a, String b, int c, int d, int e) {
		brandName=a;
		color=b;
		ram=c;
		originalPrice=d;
		discountPercentage=e;
		
	}
//	void display
	
}
