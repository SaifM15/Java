package revision;

public class TestMultiplication {

	public static void main(String[] args) {

		Multiplication mt =new Multiplication();
		int result= mt.multi(20, 10, 10);
		System.out.println(result);
	}

}
