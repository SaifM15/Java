package revision;

public class Division {
	
	int Divisioncal(int a,int b) {
		int res= a/b;
		return res;
		
	}

}
