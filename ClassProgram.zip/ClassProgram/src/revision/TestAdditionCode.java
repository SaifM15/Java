package revision;

public class TestAdditionCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AdditionCode ad= new AdditionCode();
		int addres=ad.addition(10, 20);
		System.out.println(addres);
	}

}
