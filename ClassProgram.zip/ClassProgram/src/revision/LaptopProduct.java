package revision;

public class LaptopProduct {
	String brandName;
	String ram;
	String rom;
	int price;
	String color;
	
	void referencetype(String brandName,String ram,String rom,int price,String color ) {
		this.brandName=brandName;
		this.ram=ram;
		this.rom=rom;
		this.price=price;
		this.color=color;
		
	}
	void on() {
		System.out.println("on");
	}
	
	void displayAboutInfo() {
		System.out.println("The Brand name is "+brandName);
		System.out.println("The ram is " +ram);
		System.out.println("The rom is " +rom);
		System.out.println("The price is " + price);
		System.out.println("The color is " + color);
	}
	 
	void off() {
		System.out.println("off");
		
	}

}
