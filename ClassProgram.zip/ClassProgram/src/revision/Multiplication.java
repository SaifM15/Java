package revision;

public class Multiplication {
	
	int multi(int a, int b,int c) {
		int res=a*b*c;
		return res;
	}

}
