package revision;

public class TestLaptopProduct {
	public static void main(String[] args) {
		
		LaptopProduct lp = new LaptopProduct();
		lp.on();
		lp.referencetype("HP", "8 gb","120 Gb", 26588,"gray");
		lp.displayAboutInfo();
		lp.off();
	}

}
