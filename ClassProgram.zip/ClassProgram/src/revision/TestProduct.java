package revision;

public class TestProduct {

	public static void main(String[] args) {
		
		Product p = new Product();
		p.brandName="Redmi 13 C";
		p.color="Starshine green";
		p.ram="4 GB";
		p.romStorage="128 GB";
		p.camera="50  MP";
		p.display="90 HZ";
		p.originalprice=11999;
		p.percentage=25;
		p.displayproduct();
		int price=p.discout();
		System.out.println("The main price "+price);
	}

}
