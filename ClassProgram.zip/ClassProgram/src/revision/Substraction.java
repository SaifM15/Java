package revision;

public class Substraction {
	
	int sub(int a,int b) {
		int res= a-b;
		return res;
	}

}
