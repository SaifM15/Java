
// WAP to accept two input and gives the output as addition result??
package revision;

public class AdditionCode {
	
	int addition(int a, int b) {
		int res=a+b;
		return res;
	}
	

}
