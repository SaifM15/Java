package revision;

public class TestProductPhone {

	public static void main(String[] args) {
		
		ProductPhone pp= new ProductPhone();
		pp.setvalueInstanceVariable("redmi", "red", 64, 11999, 25);
		

	}

}
