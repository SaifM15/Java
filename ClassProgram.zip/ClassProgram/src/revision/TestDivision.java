package revision;

public class TestDivision {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Division d= new Division();
		double result= d.Divisioncal(20, 5);
		System.out.println(result);
	}

}
