package revision;

public class TestSubstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Substraction sc= new Substraction();
		int result=sc.sub(50, 20);
		System.out.println(result);
	}

}
