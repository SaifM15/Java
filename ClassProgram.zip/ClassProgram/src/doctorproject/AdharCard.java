package doctorproject;

public class AdharCard {
	
	String name;
	String Surname;
	long adharNumber;
	String dob;
	

}
