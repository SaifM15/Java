package doctorproject;

import java.util.Scanner;

public class TestDoctorProject {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		AdharCard ad= new AdharCard();
		System.out.println("Please give the name");
		ad.name=sc.nextLine();
		ad.Surname="More";
		System.out.println("adhar card nmber");
		ad.adharNumber=sc.nextLong();
		ad.dob="16/06/2000";
		
		PanCard pc = new PanCard();
		pc.name="Sagar";
		pc.address="Pune";
		pc.dob="16/06/2000";
		pc.panNumber="POI987";
				
		
		DoctorProject dp = new DoctorProject();
		dp.id=101;
		dp.doctorName="Sagar";
		dp.doctorSurname="More";
		dp.hospitalName="Spandan";
		dp.age=26;
		
		dp.adharcard=ad;
		dp.pancard=pc;
		dp.info();
		
		
		
		
		
	}

}
