package doctorproject;

public class PanCard {
	
	String name;
	String panNumber;
	String dob;
	String address;

}
