package doctorproject;

public class DoctorProject {

	int id;
	String doctorName;
	String doctorSurname;
	String hospitalName;
	int age;
	
	PanCard pancard;
	AdharCard adharcard;
	
	void info() {
		System.out.println("The doctor id is " + id);
		System.out.println("The doctor name is " + doctorName);
		System.out.println("The doctor Surname is " + doctorSurname);
		System.out.println("The doctor hospital name is " + hospitalName);
		
		System.out.println("The Adhar name is " + adharcard.name );
		System.out.println("The Surname is " + adharcard.Surname);
		System.out.println("The adharNumber is " + adharcard.adharNumber);
		System.out.println("The dob is " + adharcard.dob);

		System.out.println("The Pan Name is " + pancard.name);
		System.out.println("The pan Number is " + pancard.panNumber);
		System.out.println("The pan dob is "+ pancard.dob);
		System.out.println(pancard.address);
		
		
	}

}
