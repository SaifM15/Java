package employeedetails;

public class TestEmployee {

	public static void main(String[] args) {
		
		AdharCard adhar = new AdharCard();
		adhar.name="Sahil";
		adhar.address="Pune";
		adhar.adharNumber="9997";
		adhar.dateOfBirth="13/07/2001";
				
		PanCard pan = new PanCard();
		pan.name="Sahil";
		pan.fatherName="xyz";
		pan.panNumber="HGF987";
		pan.address="Pune";
		
		Employee em = new Employee();
		em.employeeName="Sahil";
		em.employeeId=101;
		em.companyName="JBK";
		em.address="Pune";
		em.phoneNumber=9987456466L;
		em.pancard=pan;
		em.adharcard=adhar;
		em.information();
		
	}

}
