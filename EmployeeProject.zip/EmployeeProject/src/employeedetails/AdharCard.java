package employeedetails;

public class AdharCard {
	
	String name;
	String address;
	String adharNumber;
	String dateOfBirth;
	

}
