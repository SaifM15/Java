package employeedetails;

public class PanCard {
	
	String name;
	String fatherName;
	String panNumber;
	String address;
	

}
