package employeedetails;

public class Employee {
	
	String employeeName;
	int employeeId;
	String companyName;
	String address;
	long phoneNumber;
	
	AdharCard adharcard;
	PanCard pancard;
	
	void information() {
		System.out.println("The Employee Name is " + employeeName);
		System.out.println("The Employee id is " + employeeId);
		System.out.println("The company name is " + companyName);
		System.out.println("The Address is " + address);
		System.out.println("The contact Number " + phoneNumber);
		
		System.out.println("The Adhar Memory Address is" + adharcard);
		System.out.println("The Adhar name " + adharcard.name);
		System.out.println("The Adhar Address is " + adharcard.address);
		System.out.println("The Adhar number is " + adharcard.adharNumber);
		System.out.println("The DOB is " + adharcard.dateOfBirth);
		
		System.out.println("The Pancard Memory Address is " +pancard);
		System.out.println("The Pan name is " + pancard.name);
		System.out.println("The Pan Father name is " + pancard.fatherName );
		System.out.println("The Pan Number is " + pancard.panNumber );
		System.out.println("The Pan Address is "+ pancard.address);
	}

}
