package practical;

public class SumAndCount {

	public static void main(String[] args) {
		
		int no=1234;
		int rem=0;
		int sum=0;
		int count =0;
		while(no>0) {
			rem=no%10;
			
			no=no/10;
			
			sum=(sum*10)+rem;
			
//			sum=sum+rem;
			
			count++;
			
			
		}
		System.out.println(sum);
		System.out.println(count);
		
		
	}

}
