package practical;

public class Simple {

	void m1() {
		int a = 10;
		int b = 20;
		int c = a + b;
		System.out.println(c);
	}

	public static void main(String[] args) {

		Simple s = new Simple();
		s.m1();
	}

}
