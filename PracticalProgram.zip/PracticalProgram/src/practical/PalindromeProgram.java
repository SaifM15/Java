package practical;

import java.util.Scanner;

public class PalindromeProgram {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the number you want check :- ");
			int  s = sc.nextInt();
			int  a=s;
			int sum=0;
		while(s>0) {
			int rem=s%10;
			sum=sum*10+rem;
			s=s/10;
		}
			if (a==sum) {
				System.out.println(" It is Prime Number ");
			} else {
				System.out.println(" It is not prime Number");
			
		}
	}
			
	

}
