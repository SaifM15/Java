package practical;

import java.util.Scanner;

public class Weird {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter your value");
		int n = sc.nextInt();
		for (int i = 2; i <= 20; i++) {
			if (i % 2 != 0) {
				System.out.println(" Weird");
			} else if (i % 2 == 0) {
				System.out.println("Not Weird");
			} else if (i % 2 == 2) {
				System.out.println("Weird");
			}

			else if (i < 20) {
				System.out.println("Not Weird");

			}
		}

	}

}
