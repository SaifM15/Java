package practical;

public class StarPrcatice {
	public static void main(String[] args) {
		
	
	
		System.out.print(    "  *****   ");
				
}
}