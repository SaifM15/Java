package practical;

public class Email {

	public static void main(String[] args) {
		
		String gmail="Saifmulla2000@gmail.com";
		
		if((gmail.contains("@")) && (gmail.contains("."))) {
			
			System.out.println("Standard Format");
		}
		else {
			System.out.println("Please provide correct email id");
		}

	}

}
