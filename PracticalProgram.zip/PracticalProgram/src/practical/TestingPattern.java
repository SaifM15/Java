package practical;

public class TestingPattern {

	public static void main(String[] args) {

		for (int i = 1; i <=10 ; i++) {
			System.out.print("ix");
			for (int j = 1; j <= i; j++) {
				System.out.print("ix");
				System.out.print("xi");
			}
			System.out.println(" ");

		}
	}
}
