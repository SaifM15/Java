package practical;

public class PatternProgram {

	public static void main(String[] args) {
		
		for(int i=1;i<=12;i++) 
		{
			for(int j=12;j>=i;j--) {
			System.out.print(" *");
			}
			System.out.println(" ");
		
		}
		for(int k=1;k<=8;k++) {
			System.out.println(" *");
		}
		
		
	}

}
