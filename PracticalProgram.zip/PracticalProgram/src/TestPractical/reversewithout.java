package TestPractical;

public class reversewithout {
	
	public static void main(String[] args) {
		
		int n=54321;
		int rev=0;
		
		while(n>0) {
			int remain=n%10;
			rev=rev*10+remain;
			n/=10;
			
		}
		System.out.println(rev);
	}

}
