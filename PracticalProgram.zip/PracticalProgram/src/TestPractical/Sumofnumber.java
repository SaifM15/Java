package TestPractical;

public class Sumofnumber {

	public static void main(String[] args) {
		
		int num=123456;
		int sum=0;
		while(num>0) {
			int remain=num%10;
			sum =sum+remain;
			num/=10;
		}
		System.out.println(sum);

	}

}
