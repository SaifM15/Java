package com.logic.smartprogramming;

// Square under the question mark miracle pattern
public class RightAngleQuestion {

	public static void main(String[] args) {

		for (int i = 1; i <= 10; i++) {

			char ch = 65;
			for (int j = 1; j <= i; j++) {
				System.out.print((char) i + " ");
			}
			System.out.println(" ");
		}
	}

}
